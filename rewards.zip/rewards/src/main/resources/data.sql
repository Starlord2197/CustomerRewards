INSERT INTO transactions (customer_id, amount, date) VALUES (1, 120.00, '2024-01-15');
INSERT INTO transactions (customer_id, amount, date) VALUES (1, 80.00, '2024-02-10');
INSERT INTO transactions (customer_id, amount, date) VALUES (2, 150.00, '2024-01-20');
INSERT INTO transactions (customer_id, amount, date) VALUES (2, 40.00, '2024-03-01');
INSERT INTO transactions (customer_id, amount, date) VALUES (3, 200.00, '2024-03-15');
