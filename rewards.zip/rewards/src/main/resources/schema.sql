CREATE TABLE transactions (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  customer_id BIGINT NOT NULL,
  amount DOUBLE NOT NULL,
  date DATE NOT NULL
);
